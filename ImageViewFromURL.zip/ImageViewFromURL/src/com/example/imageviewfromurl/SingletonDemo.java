package com.example.imageviewfromurl;

import java.util.ArrayList;

import android.graphics.Bitmap;

public class SingletonDemo {
	
	private static volatile SingletonDemo instance = null;
	public ArrayList<Bitmap> descargas = new ArrayList<Bitmap>();
	
	private SingletonDemo() { }
	
	public static SingletonDemo getInstance(){
		if (instance == null) {
			synchronized (SingletonDemo.class) {
				if (instance == null) {
					instance = new SingletonDemo();
				}
			}
		}
		return instance;
	}

}