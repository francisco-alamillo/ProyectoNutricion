package com.example.imageviewfromurl;

import java.util.ArrayList;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

public class Recuperar extends Activity{
	
	ImageView imageView, imageView1, imageView2, imageView3, imageView4;
	ArrayList<Bitmap> descargas;
	int _aux = 0;
	
	SingletonDemo singleton;	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.dis_imagen);
		singleton = SingletonDemo.getInstance();
		descargas = new ArrayList<Bitmap>();
		
		imageView = (ImageView) findViewById(R.id.imageView);
		imageView1 = (ImageView) findViewById(R.id.imageView1);
		imageView2 = (ImageView) findViewById(R.id.imageView2);
		imageView3 = (ImageView) findViewById(R.id.imageView3);
		imageView4 = (ImageView) findViewById(R.id.imageView4);
	
//		String URL = "http://tecwebupiiz.net/tarocha/png/close13.png";
//		setImagenes(URL);
		
    	ArrayList<String> link = new ArrayList<String>();
        link.add("http://tecwebupiiz.net/tarocha/png/close13.png");
        link.add("http://tecwebupiiz.net/tarocha/png/game27.png");
        link.add("http://tecwebupiiz.net/tarocha/png/games33.png");
        link.add("http://tecwebupiiz.net/tarocha/png/ghost2.png");
        link.add("http://tecwebupiiz.net/tarocha/png/headset6.png");

        for (int i = 0; i < 5; i++) {
			setImagenes(link.get(i));
		}
	}
	
    @Override
    protected void onResume() {

       super.onResume();
       this.onCreate(null);
    }
	
	public void setImagenes(String URL){
		//try {
			DescImg task = new DescImg();
			task.execute(new String[] { URL });
			descargas = task.getDescargas();
			_aux = task.getAux();
			descargas = singleton.descargas;
			System.out.println("TEOOOOOOOOOOOOO");
			try {
				//Toast.makeText(this, "tama�o: " + task.getDescargas().size(), Toast.LENGTH_SHORT).show();
				imageView.setImageBitmap(descargas.get(0));
				imageView1.setImageBitmap(descargas.get(1));
				imageView2.setImageBitmap(descargas.get(2));
				imageView3.setImageBitmap(descargas.get(3));
				imageView4.setImageBitmap(descargas.get(4));
			} catch (Exception e) {
				// TODO: handle exception
				//Toast.makeText(this, ""+e, Toast.LENGTH_SHORT).show();
			}
	}
}