package com.example.imageviewfromurl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaScannerConnection;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends Activity {

	    ImageView imageView, imageView1, imageView2, imageView3, imageView4;
	    ProgressDialog pDialogo;
	    ArrayList<String> links;
	    ArrayList<Bitmap> descargas;
	    int aux = 0;
	 
	    /** Called when the activity is first created. */
	    @Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.activity_main);
	        
	        links = new ArrayList<String>();
	        descargas = new ArrayList<Bitmap>();
	        imageView = (ImageView) findViewById(R.id.imageView);
	        imageView1 = (ImageView) findViewById(R.id.imageView1);
	        imageView2 = (ImageView) findViewById(R.id.imageView2);
	        imageView3 = (ImageView) findViewById(R.id.imageView3);
	        imageView4 = (ImageView) findViewById(R.id.imageView4);
	        
	        start();

//	        links.add("http://tecwebupiiz.net/tarocha/png/close13.png");
//	        links.add("http://tecwebupiiz.net/tarocha/png/game27.png");
//	        links.add("http://tecwebupiiz.net/tarocha/png/games33.png");
//	        links.add("http://tecwebupiiz.net/tarocha/png/ghost2.png");
//	        links.add("http://tecwebupiiz.net/tarocha/png/headset6.png");
//
//	        for (int i = 0; i < 5; i++) {
//				ejecutar(links.get(i));
//			}
	    }
	    
	    
	    public void start(){
	    	ArrayList<String> link = new ArrayList<String>();
	        link.add("http://tecwebupiiz.net/tarocha/png/close13.png");
	        link.add("http://tecwebupiiz.net/tarocha/png/game27.png");
	        link.add("http://tecwebupiiz.net/tarocha/png/games33.png");
	        link.add("http://tecwebupiiz.net/tarocha/png/ghost2.png");
	        link.add("http://tecwebupiiz.net/tarocha/png/headset6.png");

	        for (int i = 0; i < 5; i++) {
				ejecutar(link.get(i));
			}
	    }
	     
	    public ArrayList<String> getLinks() {
			return links;
		}

		public ArrayList<Bitmap> getDescargas() {
			return descargas;
		}

		public void mandarClase(){
	    	Intent i = new Intent(this, Recuperar.class);
	    	startActivity(i);
	    }
	    
	    public void ejecutar(String URL){
	        // Create an object for subclass of AsyncTask
	        GetXMLTask task = new GetXMLTask();
	        // Execute the task
	        task.execute(new String[] { URL });
	    }
	    
	    public void mensaje (String aux){
	    	Toast.makeText(this, aux, Toast.LENGTH_SHORT).show();
	    }
	    
	    public void guardarImagen(Bitmap imagenInternet){

	    	//Guardar imagen
            String root = Environment.getExternalStorageDirectory().toString  (); //Ra�z de la tarjeta SD
            File myDir = new File(root + "/carpeta"); //Carpeta donde guardamos la imagen

            if(!myDir.exists()) //Si no existe el directorio
            	myDir.mkdirs(); //Creamos el directorio

            Random generator = new Random(); //Generamos un random para el nombre de la imagen
            int n = 10000;
            n = generator.nextInt(n);
            String fname = "wp-"+ n +".jpg"; //El nombre de la imagen con el random creado
            File file = new File (myDir, fname); //Creamos un file con la carpeta y el nombre
            
            if (file.exists ()) file.delete (); //Si existe el fichero lo eliminamos

            try {
                FileOutputStream out = new FileOutputStream(file); //A�adimos el fichero a un FileOutputStream
                imagenInternet.compress(Bitmap.CompressFormat.JPEG  , 100, out); //Pasamos la imagen a JPEG con calidad 100 y le a�adimos el output (imagenInternet es el bitmap)
                out.flush(); //Guardamos
                out.close(); //Cerramos el flujo
                MediaScannerConnection.scanFile(this, new String[]{file.getPath()}, new String[]{"image/jpeg"}, null); //Esto refresca la galer�a de im�genes de Android con la nueva imagen
                //Toast.makeText(this, "Se ha guardado la imagen", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Log.e("FALLO AL GUARDAR",e.getMessage()+""); //Mostramos por consola si ha habido alg�n error.
            }
	    }

		private class GetXMLTask extends AsyncTask<String, Void, Bitmap> {
	        @Override
	        protected Bitmap doInBackground(String... urls) {
	            Bitmap map = null;
	            for (String url : urls) {
	                map = downloadImage(url);
	            }
	            return map;
	        }
	        
	        @Override
	        protected void onPreExecute() {
	        	// TODO Auto-generated method stub
	        	super.onPreExecute();
	        	
				/*pDialogo = new ProgressDialog(MainActivity.this);
				pDialogo.setMessage("Descargando..");
				pDialogo.setIndeterminate(false);
				pDialogo.setCancelable(false);
				pDialogo.show();*/
	        }
	 
	        // Sets the Bitmap returned by doInBackground
	        @Override
	        protected void onPostExecute(Bitmap result) {
	            //imageView.setImageBitmap(result);
	        	//pDialogo.dismiss();
	            descargas.add(result);
	            aux++;
	            String aux2 = Integer.toString(aux);
	            //mensaje(aux2);
	            
	            switch (aux) {
				case 1:
					imageView.setImageBitmap(descargas.get(0));
					break;
				case 2:
					imageView1.setImageBitmap(descargas.get(1));
					break;
				case 3:
					imageView2.setImageBitmap(descargas.get(2));
					break;
				case 4:
					imageView3.setImageBitmap(descargas.get(3));
					break;
				case 5:
					imageView4.setImageBitmap(descargas.get(4));
					mandarClase();
					break;
				default:
					break;
				}
	        }

			// Creates Bitmap from InputStream and returns it
	        private Bitmap downloadImage(String url) {
	            Bitmap bitmap = null;
	            InputStream stream = null;
	            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
	            bmOptions.inSampleSize = 1;
	 
	            try {
	                stream = getHttpConnection(url);
	                bitmap = BitmapFactory.
	                        decodeStream(stream, null, bmOptions);
	                stream.close();
	            } catch (IOException e1) {
	                e1.printStackTrace();
	            }
	            return bitmap;
	        }
	 
	        // Makes HttpURLConnection and returns InputStream
	        private InputStream getHttpConnection(String urlString)
	                throws IOException {
	            InputStream stream = null;
	            URL url = new URL(urlString);
	            URLConnection connection = url.openConnection();
	 
	            try {
	                HttpURLConnection httpConnection = (HttpURLConnection) connection;
	                httpConnection.setRequestMethod("GET");
	                httpConnection.connect();
	 
	                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
	                    stream = httpConnection.getInputStream();
	                }
	            } catch (Exception ex) {
	                ex.printStackTrace();
	            }
	            return stream;
	        }
	    }
}