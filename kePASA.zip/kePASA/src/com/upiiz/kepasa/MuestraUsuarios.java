package com.upiiz.kepasa;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;
import com.upiiz.kepasa.MainActivity.loginAsincrono;
import android.app.Activity;
import android.app.ProgressDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaScannerConnection;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MuestraUsuarios extends Activity implements OnItemClickListener {
	
	ListView listaDatos;
	ArrayAdapter<String> adaptador;
	ArrayList<String> listAdapter;
	ArrayList<String> listFechas;
	ArrayList<String> listNotificacion;
	ConexionRemota miConexion;
	JSONObject Respuesta;
	///////////////////////////////////////
    ArrayList<String> links;
    ArrayList<Bitmap> descargas;
    int aux = 0;
    ///////////////////////////////////////
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.lista_usuarios);
		
		listAdapter = new ArrayList<String>();
		listFechas = new ArrayList<String>();
		listNotificacion = new ArrayList<String>();
		listaDatos = (ListView) findViewById(R.id.lvMuestraDatos);
		
		/////////////////////////////////////
        links = new ArrayList<String>();
        descargas = new ArrayList<Bitmap>();
        //////////////////////////////////////
        links.add("http://tecwebupiiz.net/tarocha/png/close13.png");
        links.add("http://tecwebupiiz.net/tarocha/png/game27.png");
        links.add("http://tecwebupiiz.net/tarocha/png/games33.png");
        links.add("http://tecwebupiiz.net/tarocha/png/ghost2.png");
        links.add("http://tecwebupiiz.net/tarocha/png/headset6.png");
        ////////////////////////////////////////////////////////////////////////
        for (int i = 0; i < 5; i++) {
			ejecutar(links.get(i));
		}
        ////////////////////////////////////////////////////////////////////////
		
		recuperaDatos();
		crearAdapatador();
	}
	
	public void crearAdapatador(){
		Adaptador miAdaptador = new Adaptador(this, listAdapter, listFechas, listNotificacion);
		listaDatos.setAdapter(miAdaptador);
		listaDatos.setOnItemClickListener(this);
	}
	
	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		
	}
	
	public void toast(String datos){
		Toast.makeText(this, datos , Toast.LENGTH_SHORT).show();
	}
	
	private void recuperaDatos(){
		AdminDB BD = new AdminDB(this, "kePasa", null, 1);
		SQLiteDatabase miBase = BD.getReadableDatabase();
		Cursor resultado = miBase.rawQuery("SELECT * FROM Usuario", null);
		
		resultado.moveToFirst();
		
		int usuario = resultado.getColumnIndex("nombre");
		int fecha = resultado.getColumnIndex("fecha");
		int noti = resultado.getColumnIndex("notificacion");
		
		while (resultado.moveToNext()) {
			String nombre = resultado.getString(usuario);
			String fechas = resultado.getString(fecha);
			String notificacion1 = resultado.getString(noti);
			listAdapter.add(nombre);
			listFechas.add(fechas);
			listNotificacion.add(notificacion1);
		}
	}
	
    public void ejecutar(String URL){
        // Create an object for subclass of AsyncTask
        GetXMLTask task = new GetXMLTask();
        // Execute the task
        task.execute(new String[] { URL });
    }
    
    public void mensaje (String aux){
    	Toast.makeText(this, aux, Toast.LENGTH_SHORT).show();
    }
    
    public void guardarImagen(Bitmap imagenInternet){

    	//Guardar imagen
        String root = Environment.getExternalStorageDirectory().toString  (); //Ra�z de la tarjeta SD
        File myDir = new File(root + "/carpeta"); //Carpeta donde guardamos la imagen

        if(!myDir.exists()) //Si no existe el directorio
        	myDir.mkdirs(); //Creamos el directorio

        Random generator = new Random(); //Generamos un random para el nombre de la imagen
        int n = 10000;
        n = generator.nextInt(n);
        String fname = "wp-"+ n +".jpg"; //El nombre de la imagen con el random creado
        File file = new File (myDir, fname); //Creamos un file con la carpeta y el nombre
        
        if (file.exists ()) file.delete (); //Si existe el fichero lo eliminamos

        try {
            FileOutputStream out = new FileOutputStream(file); //A�adimos el fichero a un FileOutputStream
            imagenInternet.compress(Bitmap.CompressFormat.JPEG  , 100, out); //Pasamos la imagen a JPEG con calidad 100 y le a�adimos el output (imagenInternet es el bitmap)
            out.flush(); //Guardamos
            out.close(); //Cerramos el flujo
            MediaScannerConnection.scanFile(this, new String[]{file.getPath()}, new String[]{"image/jpeg"}, null); //Esto refresca la galer�a de im�genes de Android con la nueva imagen
            //Toast.makeText(this, "Se ha guardado la imagen", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e("FALLO AL GUARDAR",e.getMessage()+""); //Mostramos por consola si ha habido alg�n error.
        }
    }

	private class GetXMLTask extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
            Bitmap map = null;
            for (String url : urls) {
                map = downloadImage(url);
            }
            return map;
        }
        
        @Override
        protected void onPreExecute() {
        	// TODO Auto-generated method stub
        	super.onPreExecute();
        	
			/*pDialogo = new ProgressDialog(MainActivity.this);
			pDialogo.setMessage("Descargando..");
			pDialogo.setIndeterminate(false);
			pDialogo.setCancelable(false);
			pDialogo.show();*/
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
            //imageView.setImageBitmap(result);
        	//pDialogo.dismiss();
            descargas.add(result);
            aux++;
            String aux2 = Integer.toString(aux);
            mensaje(aux2);
           
            
        }

		// Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
            Bitmap bitmap = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
 
            try {
                stream = getHttpConnection(url);
                bitmap = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return bitmap;
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
}