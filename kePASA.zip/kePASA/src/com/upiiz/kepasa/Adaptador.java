package com.upiiz.kepasa;

import java.util.ArrayList;

import android.app.Activity;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class Adaptador extends BaseAdapter {
	
	Activity a;
	ArrayList<String> d;
	ArrayList<String> f;
	ArrayList<Bitmap> img;
	ArrayList<String> noti;
	
	public Adaptador(Activity a, ArrayList<String> d, ArrayList<String> f, ArrayList<String> noti/*, ArrayList<Bitmap> img*/) {
		// TODO Auto-generated constructor stub
		this.a = a;
		this.d = d;
		this.f = f;
		this.noti = noti;
		//this.img = img;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return d.size();
	}

	@Override
	public Object getItem(int i) {
		// TODO Auto-generated method stub
		return d.get(i);
	}

	@Override
	public long getItemId(int id) {
		// TODO Auto-generated method stub
		return id;
	}

	@Override
	public View getView(int pos, View v, ViewGroup grupo) {
		// TODO Auto-generated method stub
		LayoutInflater inflater = a.getLayoutInflater();
		View renglon = inflater.inflate(R.layout.dis_registro, null);
		
		TextView nomRenglon = (TextView) renglon.findViewById(R.id.tvNombre);
		TextView fecha = (TextView) renglon.findViewById(R.id.tvUltimoAcceso);
		TextView notif = (TextView) renglon.findViewById(R.id.tvMNLeidos);
		//ImageView imagenes = (ImageView) renglon.findViewById(R.id.logo);
		
		nomRenglon.setText(d.get(pos));
		fecha.setText(f.get(pos));
		notif.setText(noti.get(pos));
		//imagenes.setImageBitmap(img.get(pos));
		
		return renglon;
	}

}
