package com.upiiz.kepasa;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity implements OnClickListener {
	
	Button ingresar, salir;
	ConexionRemota miConexion;
	JSONObject Respuesta;
	ProgressDialog pDialogo;
	EditText usuario, pass;
	TextView estatus;
	AlertDialog respLogin;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		ingresar = (Button) findViewById(R.id.btnIngresar);
		salir = (Button) findViewById(R.id.btnSalir);
		usuario = (EditText) findViewById(R.id.etUsuario);
		pass = (EditText) findViewById(R.id.etPass);
		estatus = (TextView) findViewById(R.id.estatus);
		
		ingresar.setOnClickListener(this);
		salir.setOnClickListener(this);
		
		this.deleteDatabase("kePasa");
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	@SuppressWarnings("deprecation")
	public void mensajeLogin(String msg){
		
		AlertDialog alertDialog = new AlertDialog.Builder(this).create();
		alertDialog.setTitle("Log in");
		alertDialog.setMessage(msg);
		alertDialog.setButton("Aceptar", new DialogInterface.OnClickListener() {
		public void onClick(DialogInterface dialog, int which) {
		// aqu� puedes a�adir funciones
		}
		});
		//alertDialog.setIcon(R.drawable.icono2);
		alertDialog.show();
	}
	

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		switch (v.getId()) {
		
		case R.id.btnIngresar:
			new loginAsincrono().execute();

			break;
			
		case R.id.btnSalir:
			finish();
			break;

		default:
			break;
		}
	}
	
	public void mandarClase(){
		Intent i = new Intent(this, ConsultaDB.class);
		startActivity(i);
	}
	
	private void enviarLogin(){
		
		String url = "http://tecwebupiiz.net/tarocha/pruebas_php/login.php";
		List<NameValuePair> parametros = new ArrayList<NameValuePair>(); 
		miConexion = new ConexionRemota();
		
		parametros.add( new BasicNameValuePair("user", usuario.getText().toString()));
		parametros.add( new BasicNameValuePair("pass", pass.getText().toString()));
		
		Respuesta = miConexion.respuestaConexion(url, parametros);		
	}
	
	private void enviarConexion(String nomb, String date){
		
		String url = "http://tecwebupiiz.net/tarocha/pruebas_php/ultimaconexion.php";
		List<NameValuePair> parametros = new ArrayList<NameValuePair>(); 
		miConexion = new ConexionRemota();
		
		parametros.add( new BasicNameValuePair("nombre", nomb));
		parametros.add( new BasicNameValuePair("fecha", date));
		
		Respuesta = miConexion.respuestaConexion(url, parametros);		
	}
	
	class loginAsincrono extends AsyncTask<String, String, String>{

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			// Que hacer antes de la conexi�n
			pDialogo = new ProgressDialog(MainActivity.this);
			pDialogo.setMessage("Cargando...");
			pDialogo.setIndeterminate(false);
			pDialogo.setCancelable(false);
			pDialogo.show();
		}
		
		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			// Cuando reliza la conexion
			
			String nomb = usuario.getText().toString(); 
			long date = System.currentTimeMillis();
			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss yyyy/MM/d");
			String dateString = sdf.format(date);
			enviarConexion(nomb, dateString);
			enviarLogin();
			return null;
		}
		
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			pDialogo.dismiss();
			//mandarClase();
			
			// Despues de recuperar los datos
			try {
				int estatusLogin = Respuesta.getInt("estatus");
				String m = Respuesta.getString("mensaje");
				if(estatusLogin == 0){
					mensajeLogin(m);
				}else{
					mandarClase();
				}
				
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		}	
	}
}
