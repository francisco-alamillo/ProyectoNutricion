package com.upiiz.kepasa;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Toast;

public class ConsultaDB extends Activity {
	
	//public static String URL = "http://tecwebupiiz.net/leslie/imagenes/";
	ConexionRemota miConexion;
	JSONObject Respuesta;
	ProgressDialog pDialogo;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.precesando);
		
		agregarUsuarioInicial();
		new loginAsincrono().execute();
	}
	
	private  void enviaRegistro(){
		
		String url = "http://tecwebupiiz.net/tarocha/pruebas_php/usuarios.php";
		List<NameValuePair> parametros = new ArrayList<NameValuePair>(); 
		miConexion = new ConexionRemota();
		
		parametros.add( new BasicNameValuePair("user", "a"));
		parametros.add( new BasicNameValuePair("pass", "a"));
		
		Respuesta = miConexion.respuestaConexion(url, parametros);
	}

	class loginAsincrono extends AsyncTask<String, String, String>{

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			pDialogo = new ProgressDialog(ConsultaDB.this);
			pDialogo.setMessage("Buscando datos...");
			pDialogo.setIndeterminate(false);
			pDialogo.setCancelable(false);
			pDialogo.show();
			}
		
		@Override
		protected String doInBackground(String... params) {

			enviaRegistro();
			return null;
		}
		
		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			
			try {
				int numero = Respuesta.getInt("numero");
				for (int i = 1; i < numero; i++) {
					String nombres = Respuesta.getString("nombre"+i);
					String fechas = Respuesta.getString("fecha"+i);
					String notifica = Respuesta.getString("notificacion"+i);

					agregarUsuario(nombres, fechas, "img", notifica + " mensajes sin leer");
				}
	
			} catch (JSONException e) {
				e.printStackTrace();
			}
			mandaClase();
			pDialogo.dismiss();
		}	
	}
	
	private void agregarUsuarioInicial(){
		AdminDB BD = new AdminDB(this, "kePasa", null, 1);
		SQLiteDatabase miBase = BD.getWritableDatabase();
		
		miBase.execSQL("INSERT INTO Usuario(" +
				"nombre, imagen, notificacion, fecha)" +
				"VALUES ( '" + "nomb" + "', " +
				"'" + "00/00/00" + "', " +
				"'" + "00/00/00" + "', " +
				"'" + "00/00/00" + "'" +
				")");
		miBase.close();
	}
	
	private void agregarUsuario(String _nombre, String _fecha, String _imagen, String _notificacion){
		AdminDB BD = new AdminDB(this, "kePasa", null, 1);
		SQLiteDatabase miBase = BD.getWritableDatabase();
		
		miBase.execSQL("INSERT INTO Usuario(" +
				"nombre, imagen, notificacion, fecha)" +
				"VALUES ( '" + _nombre + "', " +
				"'" + _imagen + "', " +
				"'" + _notificacion + "', " +
				"'" + _fecha + "'" +
				")");
		miBase.close();
	}
	
	public void mandaClase(){
		Intent i = new Intent(this, MuestraUsuarios.class);
		startActivity(i);
	}
	
	public void nombresinis(String m){
		Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
	}
	
	private void eliminarUsuarioInicial(String nombre){
		AdminDB BD = new AdminDB(this, "kePasa", null, 1);
		SQLiteDatabase miBase = BD.getWritableDatabase();
		
		miBase.execSQL("DELETE FROM Usuario WHERE nombre ='" + nombre +"'");
		miBase.close();
	}
	
}
