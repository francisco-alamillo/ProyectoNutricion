/** Automatically generated file. DO NOT MODIFY */
package com.upiiz.kepasa;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}